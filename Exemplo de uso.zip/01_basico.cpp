#include<opencv/cv.hpp>
#include<opencv2/highgui/highgui.hpp>
//para rodar no linux:
//gcc -ggdb `pkg-config --cflags opencv` -o `basename 01_basico` 01_basico.cpp `pkg-config --libs opencv`

using namespace cv;

int main()
{
    Mat img = imread("fruits.jpg",CV_LOAD_IMAGE_COLOR);
    imshow("opencvtest",img);
    waitKey(0);

    return 0;
}
